
Single File PHP Gallery TEST FILE 1.5.1

This is a test script for testing if server requirements are met for Single File PHP Gallery to run.
Place this file in the directory where you want Single File PHP Gallery to be.
Access the file from a browser. The output should tell if you if Single File PHP Gallery would be able to run.

If the output from the script does not provide enough information for you to make the script work,
then please use the contact form on the Single File PHP Gallery page.
Describe the issue you are having and also include the information from the SFPG TEST script.

Download latest version here:
http://sye.dk/sfpg/
